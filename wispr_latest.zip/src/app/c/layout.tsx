export default function ComplimentsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
