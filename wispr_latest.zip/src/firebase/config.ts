export const firebaseConfig = {
  "projectId": "studio-7612144134-fcc76",
  "appId": "1:336714023784:web:4190c771fc83e14eeb4cdd",
  "apiKey": "AIzaSyBJ1YopHxP78CvQARIbf65QzOBGZxxgA4A",
  "authDomain": "studio-7612144134-fcc76.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "336714023784"
};
